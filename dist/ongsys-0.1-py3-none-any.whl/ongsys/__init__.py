#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 21:10:06 2023

@author: nfamartins
"""

from .get_data import get_data
from .prep_data import prep_data